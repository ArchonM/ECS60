#!/bin/bash
./consistentresultverification.exe $1 $2
