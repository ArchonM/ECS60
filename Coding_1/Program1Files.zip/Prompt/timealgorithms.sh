#!/bin/bash
./timealgorithms.exe $1
